#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<stdbool.h>
bool c[13][4]={false};
char name[13][20]={"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
char type[4][20]={"CO","RO","BICH","TEP"};
void Distribute(int order){
	srand(time(NULL));
	int count[13]={0};
	int cards_num=0;
	int x;
	int row,column;
	printf("\tPlayer %d has the following cards :\n",order);
	while(cards_num != 13){
		x =  rand()% 52;
		row = x/4;
		column = x%4;
		while(c[row][column]==true && row <= 12){
			x++;
			row = x/4;
		    column = x%4;}
		if(row>12){
			for(row=0;row<13;row++){
				for(column=0;column<4;column++){
					if(c[row][column]==false){
						goto PRINT;}}}}
		PRINT :
		cards_num++;
		c[row][column]=true;
		count[row]++;
		printf("\t\t - %s %s\n",name[row],type[column]);}
		for(x=0;x<13;x++){
			if(count[x]==4){
				printf("\t\t ** He has FOUR-OF-A-KIND %s !!!\n",name[x]);}}}
			
int main(){
	int i=1;
	while(i<=4){
		Distribute(i++);}
return 0 ;
}

