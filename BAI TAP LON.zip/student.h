typedef struct SinhVien{
    char name[30];
    float score; 
}SV;

