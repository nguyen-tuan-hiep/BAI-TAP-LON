#include <stdio.h>

int v[1010], g[1010], p[1010];
char *name[1010];
float x[1010];

int f[1010][1010];

int max(int a,int b){
    return a<b ? b : a;
}

int main(){

    FILE *file;
    file = fopen("knapsack.inp","r");

    int n, w;
    fscanf(file,"%d%d",&n,&w);
    
	int i,j,t;
    for(i=0;i<1000;++i)
        for(j=0;j<1000;++j)
            f[i][j]=-1;

    f[0][w]=0;

    for(i=1;i<=n;++i){
        fscanf(file,"%d%d%s",&g[i],&v[i],&name[i]);
        for(j=0;j<1000;++j) if(f[i-1][j]>=0){
            for(t=0;t<1000;++t){
                if(j-t*g[i]<0)
                    break;
                f[i][j-t*g[i]]=max(f[i][j-t*g[i]], f[i-1][j] + v[i]*t);
            }
        }
    }

    int best=0;

    for(i=0;i<1000;++i)
        best=max(best,f[n][i]);

    printf("%d",best);


    fclose(file);


}
