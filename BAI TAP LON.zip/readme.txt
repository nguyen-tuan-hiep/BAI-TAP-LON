Đây là bài tập lớn của nhóm em (gồm Nguyễn Tuấn Hiệp-20205151 và Lê Hoàng Hải-20205182)

Bài 1 gồm 1 file: Bai1.c
Bài 2 gồm 2 file: Bai2.c và Bai2.inp (dữ liệu nhập ở  trong file Bai2.inp)
Bài 3 gồm 4 file: Bai3.c, student.h, SV2021.dat và output.txt
Bài 4 gồm 1 file: Bai4.c